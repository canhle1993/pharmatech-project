export const env = {
  baseUrl: 'http://localhost:3000/api/',
  imageUrl: 'http://localhost:3000/upload/',
};
