// src/application/application.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

@Schema({
  collection: 'applications',
  versionKey: false,
  timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
})
export class Application extends Document {
  // 🔗 Liên kết
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: 'Account', required: true })
  account_id: any;

  @Prop({ type: MongooseSchema.Types.ObjectId, ref: 'Career', required: true })
  career_id: any;

  // 📄 Thông tin hồ sơ nộp

  @Prop()
  cover_letter?: string;

  @Prop()
  portfolio?: string;

  @Prop()
  expected_salary?: number;

  @Prop()
  available_from?: Date;

  // 🧠 Trạng thái xử lý
  @Prop({ default: 'pending' })
  status: string; // pending | assigned | interview | hired | rejected

  // 🗑️ Soft delete flag
  @Prop({ type: Boolean, default: true })
  is_active: boolean;

  @Prop()
  reviewed_date?: Date;

  @Prop()
  note?: string;

  // 👑 SuperAdmin phân công Admin
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: 'Account', default: null })
  assigned_admin_id?: string;

  @Prop({ type: String, default: null })
  assigned_admin_name?: string;

  @Prop({ type: Date })
  assigned_at?: Date;

  // 🗓️ Lên lịch phỏng vấn
  @Prop({ type: Date })
  interview_date?: Date;

  @Prop({ type: String })
  interview_location?: string;

  @Prop({ type: String })
  interview_email_content?: string;

  // 📧 Email đã gửi chưa
  @Prop({ type: Boolean, default: false })
  email_sent?: boolean;

  // 🧾 Kết quả phỏng vấn
  @Prop({ type: String })
  result?: string; // pass | fail | pending

  @Prop({ type: Date })
  hired_start_date?: Date;

  @Prop({ type: String })
  hired_department?: string;

  // 🟩 PASS fields
  @Prop({ type: Date })
  pass_date?: Date;

  @Prop({ type: Date })
  start_work_date?: Date;

  @Prop({ type: String })
  pass_location?: string;

  @Prop({ type: String })
  pass_email_content?: string;

  // 🟥 REJECT fields
  @Prop({ type: Date })
  reject_date?: Date;

  @Prop({ type: String })
  reject_reason?: string;

  @Prop({ type: String })
  reject_email_content?: string;

  @Prop({ type: String })
  rejected_by?: string;

  // Thời gian tạo / cập nhật
  @Prop()
  created_at?: Date;

  @Prop()
  updated_at?: Date;
}

export const ApplicationSchema = SchemaFactory.createForClass(Application);
