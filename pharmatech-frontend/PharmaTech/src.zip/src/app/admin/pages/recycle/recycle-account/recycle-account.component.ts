import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './recycle-account.component.html',
  styleUrls: ['./recycle-account.component.css'],
})
export class RecycleAccountComponent implements OnInit {
  ngOnInit(): void {}
}
