import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './news.component.html',
})
export class NewsComponent implements OnInit {
  ngOnInit(): void {}
}
