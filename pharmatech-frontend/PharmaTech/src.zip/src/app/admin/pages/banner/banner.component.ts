import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css'],
})
export class BannerComponent implements OnInit {
  ngOnInit(): void {}
}
