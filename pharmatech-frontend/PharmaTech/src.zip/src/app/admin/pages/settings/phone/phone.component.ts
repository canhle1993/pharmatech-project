import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './phone.component.html',
  styleUrls: ['./phone.component.css'],
})
export class PhoneComponent implements OnInit {
  ngOnInit(): void {}
}
