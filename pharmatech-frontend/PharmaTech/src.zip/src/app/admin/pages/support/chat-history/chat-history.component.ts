import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './chat-history.component.html',
  styleUrls: ['./chat-history.component.css'],
})
export class ChatHistoryComponent implements OnInit {
  ngOnInit(): void {}
}
