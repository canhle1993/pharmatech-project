import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css'],
})
export class OrderListComponent implements OnInit {
  ngOnInit(): void {}
}
