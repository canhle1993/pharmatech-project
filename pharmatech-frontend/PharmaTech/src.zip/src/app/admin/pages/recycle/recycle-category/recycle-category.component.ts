import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './recycle-category.component.html',
  styleUrls: ['./recycle-category.component.css'],
})
export class RecycleCategoryComponent implements OnInit {
  ngOnInit(): void {}
}
