import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './zalo.component.html',
  styleUrls: ['./zalo.component.css'],
})
export class ZaloComponent implements OnInit {
  ngOnInit(): void {}
}
