import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css'],
})
export class OrderDetailsComponent implements OnInit {
  ngOnInit(): void {}
}
