import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './recycle-product.component.html',
  styleUrls: ['./recycle-product.component.css'],
})
export class RecycleProductComponent implements OnInit {
  ngOnInit(): void {}
}
