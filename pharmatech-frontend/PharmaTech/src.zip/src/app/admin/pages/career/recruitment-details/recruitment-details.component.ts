import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './recruitment-details.component.html',
  styleUrls: ['./recruitment-details.component.css'],
})
export class RecruitmentDetailsComponent implements OnInit {
  ngOnInit(): void {}
}
