import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './recruitment-history.component.html',
  styleUrls: ['./recruitment-history.component.css'],
})
export class RecruitmentHistoryComponent implements OnInit {
  ngOnInit(): void {}
}
